"""Copies of a managed project (DiceVTT) that the coding agents may read or edit.

The real project folder is never edited by an agent and no version-control state is
created: no Plastic branch, workspace or Git worktree. Instead:

- a reference copy per conversation, read by the coordinator while it plans;
- a work copy per approved run, where the agents edit;
- a manifest of file hashes taken with each copy, so the changes can be listed and
  shown as a diff, and later applied to the real project only where the real file
  is still exactly as it was when the copy was made (anything else is a conflict).

Only the parts of a Unity project an agent needs are copied: Assets, Packages,
ProjectSettings (with every .meta file) and small files at the root. Library, Logs,
Temp, Builds, UserSettings, caches and the .plastic folder are left out.
"""

from __future__ import annotations

import difflib
import hashlib
import json
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .credentials import app_dir, local_dir

COPIED_DIRS = ("Assets", "Packages", "ProjectSettings")
ROOT_SUFFIXES = (".md", ".txt", ".json", ".conf", ".asmdef", ".slnx", ".sln")
SKIPPED_DIRS = {
    "Library",
    "Logs",
    "Temp",
    "obj",
    "Builds",
    "UserSettings",
    ".plastic",
    ".git",
    "ProfilerCaptures",
}
DIFF_FILE_LIMIT = 400_000
DIFF_TOTAL_LIMIT = 1_500_000


class WorkspaceError(Exception):
    pass


@dataclass(frozen=True)
class Project:
    key: str
    name: str
    path: Path
    vcs: str


def projects() -> dict[str, Project]:
    """Managed projects; %APPDATA%/JarvisDesktop/projects.json overrides the default."""
    config = app_dir() / "projects.json"
    raw: dict[str, Any] = {
        "dicevtt": {
            "name": "DiceVTT",
            "path": r"C:\ProjetoTablepRPG\DiceVTT",
            "vcs": "plastic",
        }
    }
    if config.exists():
        raw.update(json.loads(config.read_text(encoding="utf-8")))
    return {
        key: Project(
            key,
            str(value.get("name", key)),
            Path(value["path"]).resolve(),
            str(value.get("vcs", "none")),
        )
        for key, value in raw.items()
    }


def work_root() -> Path:
    return Path(os.environ.get("JARVIS_WORK_ROOT") or local_dir() / "work")


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _files(root: Path) -> list[Path]:
    found: list[Path] = []
    for name in COPIED_DIRS:
        top = root / name
        if not top.is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(top):
            dirnames[:] = [d for d in dirnames if d not in SKIPPED_DIRS]
            found += [Path(dirpath) / f for f in filenames]
    found += [
        p for p in root.iterdir() if p.is_file() and p.suffix.lower() in ROOT_SUFFIXES
    ]
    return found


def manifest(root: Path) -> dict[str, str]:
    """relative path (forward slashes) -> sha256, for the copied parts."""
    return {p.relative_to(root).as_posix(): _hash(p) for p in _files(root)}


def manifest_digest(files: dict[str, str]) -> str:
    return hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()[:16]


def _inside(base: Path, relative: str) -> Path:
    target = (base / relative).resolve()
    if base.resolve() not in target.parents:
        raise WorkspaceError(f"{relative} is outside the project")
    return target


def copy_project(project: Project, target: Path) -> dict[str, Any]:
    """Selective copy plus its manifest; returns where it came from."""
    if not project.path.is_dir():
        raise WorkspaceError(f"{project.path} does not exist")
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    files: dict[str, str] = {}
    for source in _files(project.path):
        relative = source.relative_to(project.path)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        files[relative.as_posix()] = _hash(destination)
    info = {
        "source": str(project.path),
        "files": len(files),
        "manifest_digest": manifest_digest(files),
        "revision": revision(project),
    }
    (target.parent / f"{target.name}.manifest.json").write_text(
        json.dumps(files), encoding="utf-8"
    )
    (target.parent / f"{target.name}.info.json").write_text(
        json.dumps(info, indent=1), encoding="utf-8"
    )
    return info


def load_manifest(target: Path) -> dict[str, str]:
    return json.loads(
        (target.parent / f"{target.name}.manifest.json").read_text(encoding="utf-8")
    )


def revision(project: Project) -> dict[str, Any]:
    """The version-control position of the real project, read-only."""
    if project.vcs != "plastic":
        return {"vcs": project.vcs}
    cm = shutil.which("cm") or r"C:\Program Files\PlasticSCM5\client\cm.exe"
    info: dict[str, Any] = {"vcs": "plastic"}
    try:
        info["workspace"] = subprocess.run(
            [cm, "wi", "."],
            cwd=project.path,
            capture_output=True,
            text=True,
            timeout=60,
        ).stdout.strip()[:300]
        pending = subprocess.run(
            [cm, "status", "--short", "."],
            cwd=project.path,
            capture_output=True,
            text=True,
            timeout=120,
        ).stdout.splitlines()
        info["pending_changes"] = len(pending)
    except (OSError, subprocess.SubprocessError) as exc:
        info["error"] = str(exc)[:200]
    return info


def changes(work: Path, base: dict[str, str]) -> dict[str, Any]:
    """What the agents changed in a work copy, with a readable diff for text files."""
    now = manifest(work)
    added = sorted(set(now) - set(base))
    deleted = sorted(set(base) - set(now))
    modified = sorted(p for p in set(now) & set(base) if now[p] != base[p])
    diff_parts: list[str] = []
    size = 0
    reference = work.parent / f"{work.name}.reference"
    for path in modified + added:
        file = work / path
        if file.stat().st_size > DIFF_FILE_LIMIT:
            diff_parts.append(f"--- {path}: too large for a text diff\n")
            continue
        try:
            new = file.read_text(encoding="utf-8").splitlines(keepends=True)
            old_file = reference / path
            old = (
                old_file.read_text(encoding="utf-8").splitlines(keepends=True)
                if old_file.exists()
                else []
            )
        except UnicodeDecodeError:
            diff_parts.append(f"--- {path}: binary file changed\n")
            continue
        chunk = "".join(difflib.unified_diff(old, new, f"a/{path}", f"b/{path}"))
        size += len(chunk)
        if size > DIFF_TOTAL_LIMIT:
            diff_parts.append("[diff truncated at the size limit]\n")
            break
        diff_parts.append(chunk)
    return {
        "added": added,
        "modified": modified,
        "deleted": deleted,
        "diff": "".join(diff_parts),
    }


def keep_reference(work: Path) -> None:
    """A pristine copy of the text files beside the work copy, for diffs."""
    reference = work.parent / f"{work.name}.reference"
    if reference.exists():
        shutil.rmtree(reference)
    for path in manifest(work):
        source = work / path
        if source.stat().st_size <= DIFF_FILE_LIMIT and source.suffix.lower() not in {
            ".png",
            ".jpg",
            ".fbx",
            ".wav",
            ".mp3",
            ".asset",
            ".unity3d",
        }:
            target = reference / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)


def apply_to_project(
    project: Project, work: Path, base: dict[str, str]
) -> dict[str, Any]:
    """Copy the agents' changes into the real project where it is safe.

    A file is applied only when the real file still has the hash it had when the
    work copy was made (or, for a new file, still does not exist). Every other file
    is reported as a conflict and left alone. Deletions are reported, not applied.
    """
    result = changes(work, base)
    applied: list[str] = []
    conflicts: list[str] = []
    for path in result["modified"] + result["added"]:
        real = _inside(project.path, path)
        expected = base.get(path)
        current = _hash(real) if real.exists() else None
        if current != expected:
            conflicts.append(path)
            continue
        real.parent.mkdir(parents=True, exist_ok=True)
        temporary = real.with_name(real.name + ".jarvis-tmp")
        shutil.copy2(work / path, temporary)
        os.replace(temporary, real)
        applied.append(path)
    return {
        "applied": applied,
        "conflicts": conflicts,
        "not_applied_deletions": result["deleted"],
    }
