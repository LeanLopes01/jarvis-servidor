"""Long jobs of the coding agents on this PC, started by the JARVIS orchestrator.

A job is one run of a CLI: the Antigravity coordinator (plan mode, read-only) or an
agent working on a task (Codex, Claude Code or Antigravity) inside the run's work
copy of the project. Starting a job returns at once; the result goes back to the
server as a "job_update" message and is repeated until the server acknowledges it.

Each job's state is a file in %LOCALAPPDATA%/JarvisDesktop/jobs, so a helper
restart cannot lose a result. A job found "running" after a restart whose process
is gone is reported as "unknown": it is never started again automatically, since it
may already have changed files.

Arguments are lists (no shell); the prompt is passed as one argument or a file.
Cancelling kills only this job's process tree.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import shutil
import tempfile
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from .credentials import local_dir
from .workspaces import (
    WorkspaceError,
    apply_to_project,
    changes,
    copy_project,
    keep_reference,
    load_manifest,
    manifest,
    projects,
    work_root,
)

logger = logging.getLogger("jarvis_desktop")

KINDS = ("coordinate", "execute")
AGENTS = ("codex", "claude", "antigravity")
OUTPUT_LIMIT = 200_000
CLAUDE_TOOLS = "Read Edit MultiEdit Write Glob Grep"
# Headless Antigravity ends the turn without output when a tool is refused. The
# coordinator then gets one more turn in the same conversation, told why.
RETRY_PROMPT = (
    "Your last command was refused. Only one pipeline of reading commands is allowed: "
    "Get-ChildItem, Get-Content or Select-String, optionally piped to Select-Object, "
    "Sort-Object, Measure-Object or Select-String; no ;, &, $(...), parentheses, braces or "
    "redirection. For example: Get-ChildItem -Recurse -Filter *.cs | Select-String -Pattern "
    "Initiative | Select-Object -ExpandProperty Path -Unique. Continue within that limit, then "
    "give your answer in the required JSON format."
)


def jobs_dir() -> Path:
    return local_dir() / "jobs"


def _exe(name: str) -> str:
    found = shutil.which(name)
    if not found:
        raise WorkspaceError(f"{name} is not installed on this computer")
    return found


def command_for(job: dict[str, Any], cwd: Path, files: Path) -> list[str]:
    """The CLI call for a job. Never a shell string."""
    prompt = job["prompt"]
    if job["kind"] == "coordinate":
        schema = files / "schema.json"
        schema.write_text(json.dumps(job["schema"]), encoding="utf-8")
        args = [
            _exe("agy"),
            "-p",
            prompt,
            "--mode",
            "plan",
            "--output-format",
            "json",
            "--json-schema",
            str(schema),
            "--print-timeout",
            f"{int(job['timeout'])}s",
            "--add-dir",
            str(cwd),
        ]
        if job.get("agy_conversation_id"):
            args += ["--conversation", job["agy_conversation_id"]]
        return args
    agent = job["agent"]
    if agent == "codex":
        return [
            _exe("codex"),
            "exec",
            "-C",
            str(cwd),
            "-s",
            "workspace-write",
            "--skip-git-repo-check",
            "--json",
            "-o",
            str(files / "last_message.txt"),
            prompt,
        ]
    if agent == "claude":
        return [
            _exe("claude"),
            "-p",
            prompt,
            "--output-format",
            "json",
            "--permission-mode",
            "acceptEdits",
            "--allowedTools",
            CLAUDE_TOOLS,
        ]
    if agent == "antigravity":
        return [
            _exe("agy"),
            "-p",
            prompt,
            "--mode",
            "accept-edits",
            "--output-format",
            "json",
            "--print-timeout",
            f"{int(job['timeout'])}s",
        ]
    raise WorkspaceError(f"unknown agent {agent}")


def read_result(job: dict[str, Any], stdout: str, files: Path) -> dict[str, Any]:
    """What the CLI reported, with honest failure signals (denied tools, no output)."""
    result: dict[str, Any] = {"exit_code": job.get("exit_code")}
    data: dict[str, Any] = {}
    if job["kind"] == "coordinate" or job.get("agent") in {"claude", "antigravity"}:
        with contextlib.suppress(ValueError):
            data = json.loads(stdout.strip().splitlines()[-1]) if stdout.strip() else {}
    if job["kind"] == "coordinate" or job.get("agent") == "antigravity":
        result.update(
            agy_conversation_id=data.get("conversation_id"),
            status=data.get("status"),
            text=data.get("response"),
            structured=data.get("structured_output"),
            denied=data.get("denied_actions") or [],
            usage=data.get("usage"),
        )
    elif job.get("agent") == "claude":
        result.update(
            text=data.get("result"),
            session_id=data.get("session_id"),
            is_error=data.get("is_error"),
            denied=data.get("permission_denials") or [],
            model=data.get("model") or (next(iter(data.get("modelUsage") or {}), None)),
        )
    elif job.get("agent") == "codex":
        last = files / "last_message.txt"
        result["text"] = (
            last.read_text(encoding="utf-8", errors="replace")
            if last.exists()
            else None
        )
        for line in stdout.splitlines():
            with contextlib.suppress(ValueError):
                event = json.loads(line)
                if event.get("type") == "thread.started":
                    result["thread_id"] = event.get("thread_id")
                if event.get("type") in {"turn.failed", "error"}:
                    result.setdefault("errors", []).append(str(event)[:500])
    ok = (
        job.get("exit_code") == 0
        and not result.get("is_error")
        and not result.get("errors")
    )
    if job["kind"] == "coordinate":
        ok = ok and isinstance(result.get("structured"), dict)
    if result.get("denied"):
        # A tool the agent needed was refused: the turn may look successful but is not.
        result["problem"] = f"tools refused: {result['denied']}"
        ok = ok and job["kind"] != "coordinate" and bool(result.get("text"))
    result["ok"] = bool(ok)
    return result


class JobManager:
    def __init__(
        self,
        directory: Path | None = None,
        *,
        notify: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.dir = directory or jobs_dir()
        self.dir.mkdir(parents=True, exist_ok=True)
        self.notify = notify
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._procs: dict[str, asyncio.subprocess.Process] = {}
        self._sent_at: dict[str, float] = {}
        self.command_for = command_for  # replaced in tests
        for job in self._all():
            if job["state"] in {"queued", "running"}:
                job.update(
                    state="unknown",
                    finished_at=time.time(),
                    result={
                        "ok": False,
                        "problem": "the helper restarted while this job ran",
                    },
                )
                self._save(job)

    # Persistence

    def _path(self, job_id: str) -> Path:
        if not job_id.replace("-", "").isalnum() or len(job_id) > 80:
            raise WorkspaceError("bad job id")
        return self.dir / f"{job_id}.json"

    def _save(self, job: dict[str, Any]) -> None:
        with tempfile.NamedTemporaryFile(
            "w", dir=self.dir, delete=False, suffix=".tmp", encoding="utf-8"
        ) as tmp:
            json.dump(job, tmp, ensure_ascii=False)
        # On Windows the rename fails while another thread is reading the file.
        for attempt in range(50):
            try:
                os.replace(tmp.name, self._path(job["id"]))
                return
            except PermissionError:
                if attempt == 49:
                    raise
                time.sleep(0.02)

    def get(self, job_id: str) -> dict[str, Any] | None:
        path = self._path(job_id)
        try:
            return (
                json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
            )
        except ValueError:
            return None

    def _all(self) -> list[dict[str, Any]]:
        jobs = []
        for path in self.dir.glob("*.json"):
            with contextlib.suppress(OSError, ValueError):
                jobs.append(json.loads(path.read_text(encoding="utf-8")))
        return jobs

    # Starting and stopping

    def start(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = str(params.get("job_id") or "")
        existing = self.get(job_id)
        if existing is not None:
            return {"job_id": job_id, "state": existing["state"]}  # sent twice
        kind = params.get("kind")
        if kind not in KINDS:
            raise WorkspaceError("unknown job kind")
        if kind == "execute" and params.get("agent") not in AGENTS:
            raise WorkspaceError("unknown agent")
        project = projects().get(str(params.get("project")))
        if project is None:
            raise WorkspaceError("unknown project")
        job = {
            "id": job_id,
            "kind": kind,
            "project": project.key,
            "agent": params.get("agent"),
            "conversation_id": params.get("conversation_id"),
            "run_id": params.get("run_id"),
            "task_id": params.get("task_id"),
            "agy_conversation_id": params.get("agy_conversation_id"),
            "prompt": str(params.get("prompt") or "")[:60_000],
            "schema": params.get("schema"),
            "timeout": min(max(float(params.get("timeout") or 600), 30), 4 * 3600),
            "state": "queued",
            "created_at": time.time(),
            "finished_at": None,
            "result": None,
        }
        self._save(job)
        self._tasks[job_id] = asyncio.ensure_future(self._run(job))
        return {"job_id": job_id, "state": "queued"}

    async def cancel(self, job_id: str) -> dict[str, Any]:
        job = self.get(job_id)
        if job is None:
            return {"job_id": job_id, "state": "unknown_job"}
        task = self._tasks.get(job_id)
        if task is not None and not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await asyncio.wait_for(asyncio.shield(task), 15)
        job = self.get(job_id) or job
        return {"job_id": job_id, "state": job["state"]}

    async def _kill(self, proc: asyncio.subprocess.Process) -> None:
        """This job's process and its children only."""
        if proc.returncode is not None:
            return
        try:
            import psutil

            parent = psutil.Process(proc.pid)
            for child in parent.children(recursive=True):
                with contextlib.suppress(psutil.Error):
                    child.kill()
            parent.kill()
        except Exception:
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(proc.wait(), 10)

    # Running

    def _workspace(self, job: dict[str, Any]) -> Path:
        project = projects()[job["project"]]
        root = work_root() / project.key
        if job["kind"] == "coordinate":
            reference = (
                root / "conversations" / str(job["conversation_id"]) / "reference"
            )
            if not reference.exists():
                job["copy"] = copy_project(project, reference)
            return reference
        work = root / "runs" / str(job["run_id"]) / "work"
        if not work.exists():
            job["copy"] = copy_project(project, work)
            keep_reference(work)
        return work

    async def _run(self, job: dict[str, Any]) -> None:
        files = self.dir / job["id"]
        files.mkdir(exist_ok=True)
        proc: asyncio.subprocess.Process | None = None
        try:
            job["state"] = "preparing"
            self._save(job)
            cwd = await asyncio.to_thread(self._workspace, job)
            args = self.command_for(job, cwd, files)
            job.update(
                state="running",
                started_at=time.time(),
                cwd=str(cwd),
                command=[*args[:1], "…"],
            )
            self._save(job)
            for attempt in range(2):
                proc = await asyncio.create_subprocess_exec(
                    *args,
                    cwd=cwd,
                    stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                self._procs[job["id"]] = proc
                job["pid"] = proc.pid
                self._save(job)
                try:
                    stdout, stderr = await asyncio.wait_for(
                        proc.communicate(), job["timeout"] + 30
                    )
                except asyncio.TimeoutError:
                    await self._kill(proc)
                    raise TimeoutError(
                        f"no result within {int(job['timeout'])} s"
                    ) from None
                job["exit_code"] = proc.returncode
                out = stdout.decode("utf-8", errors="replace")
                (files / f"stdout{attempt or ''}.txt").write_text(
                    out[-OUTPUT_LIMIT:], encoding="utf-8"
                )
                (files / f"stderr{attempt or ''}.txt").write_text(
                    stderr.decode("utf-8", errors="replace")[-OUTPUT_LIMIT:],
                    encoding="utf-8",
                )
                result = read_result(job, out, files)
                retry = (
                    attempt == 0
                    and job["kind"] == "coordinate"
                    and not result["ok"]
                    and result.get("denied")
                    and result.get("agy_conversation_id")
                )
                if not retry:
                    break
                logger.info(
                    "job %s: a tool was refused; asking the coordinator again",
                    job["id"][:8],
                )
                job["agy_conversation_id"] = result["agy_conversation_id"]
                retried = {**job, "prompt": RETRY_PROMPT}
                args = self.command_for(retried, cwd, files)
                job["first_attempt_denied"] = result.get("denied")
            if job["kind"] == "coordinate":
                # Plan mode must not change the reference copy: check, and start over if it did.
                reference = Path(job["cwd"])
                expected = load_manifest(reference)
                now = await asyncio.to_thread(manifest, reference)
                if now != expected:
                    result["reference_changed"] = sorted(
                        p
                        for p in set(now) | set(expected)
                        if now.get(p) != expected.get(p)
                    )[:50]
                    await asyncio.to_thread(shutil.rmtree, reference, True)
            if job["kind"] == "execute":
                work = Path(job["cwd"])
                result["changes"] = await asyncio.to_thread(
                    changes, work, load_manifest(work)
                )
            if job.get("first_attempt_denied"):
                result["first_attempt_denied"] = job["first_attempt_denied"]
            result["stderr_tail"] = stderr.decode("utf-8", errors="replace")[-1500:]
            job.update(state="completed" if result["ok"] else "failed", result=result)
        except asyncio.CancelledError:
            if proc is not None:
                await self._kill(proc)
            job.update(
                state="cancelled", result={"ok": False, "problem": "stopped on request"}
            )
        except Exception as exc:
            logger.exception("job %s failed", job["id"])
            job.update(
                state="failed",
                result={"ok": False, "problem": f"{type(exc).__name__}: {exc}"[:600]},
            )
        finally:
            job["finished_at"] = time.time()
            if "copy" in job and isinstance(job.get("result"), dict):
                job["result"]["copy"] = job["copy"]  # where the copy came from
            self._save(job)
            self._procs.pop(job["id"], None)
            logger.info(
                "job %s (%s %s) -> %s",
                job["id"][:8],
                job["kind"],
                job.get("agent") or "",
                job["state"],
            )
            if self.notify is not None:
                self.notify(self._message(job))

    # Reporting to the server

    @staticmethod
    def _message(job: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": "job_update",
            "job": {
                k: job.get(k)
                for k in (
                    "id",
                    "kind",
                    "agent",
                    "state",
                    "conversation_id",
                    "run_id",
                    "task_id",
                    "created_at",
                    "started_at",
                    "finished_at",
                    "result",
                )
            },
        }

    def due(self, now: float | None = None) -> list[dict[str, Any]]:
        """Finished jobs whose result the server has not acknowledged yet."""
        now = time.time() if now is None else now
        messages = []
        for job in self._all():
            if job["state"] in {"queued", "preparing", "running"} or job.get("acked"):
                continue
            if now - self._sent_at.get(job["id"], 0) < 30:
                continue
            self._sent_at[job["id"]] = now
            messages.append(self._message(job))
        return messages

    def acknowledge(self, job_id: str) -> None:
        job = self.get(job_id)
        if job is not None:
            job["acked"] = True
            self._save(job)

    def status(self, job_ids: list[str]) -> dict[str, Any]:
        return {
            job_id: (self.get(job_id) or {}).get("state", "unknown_job")
            for job_id in job_ids[:100]
        }

    def apply(self, params: dict[str, Any]) -> dict[str, Any]:
        project = projects().get(str(params.get("project")))
        if project is None:
            raise WorkspaceError("unknown project")
        work = work_root() / project.key / "runs" / str(params.get("run_id")) / "work"
        if not work.exists():
            raise WorkspaceError("this run has no work copy on this computer")
        return apply_to_project(project, work, load_manifest(work))
