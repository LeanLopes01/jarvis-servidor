"""Hook command for Claude Code and Codex: records each session's latest event.

Both agents run it asynchronously (it can never block, approve or deny anything):

    python agent_hook.py claude    # from ~/.claude/settings.json
    python agent_hook.py codex     # from ~/.codex/hooks.json

It reads the hook's JSON from stdin and replaces
%LOCALAPPDATA%/JarvisDesktop/agent-events/<agent>-<session>.json with the event, so
the coding report knows exactly when an agent is waiting for approval or for an
answer.

Every Stop and every approval or question request is also written to its own file in
%LOCALAPPDATA%/JarvisDesktop/outbox/. That file stays until the server confirms it
stored the event, so two quick finishes or a restart lose nothing; the helper sends
it (see outbox.py). Standard library only, and it always exits 0.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import tempfile
import time
import uuid
from pathlib import Path

KEEP_DAYS = 7
QUESTION_TOOLS = {"AskUserQuestion"}


def events_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    return Path(base) / "JarvisDesktop" / "agent-events"


def outbox_dir() -> Path:
    return events_dir().parent / "outbox"


def host_hint(agent: str, env: dict[str, str] | os._Environ[str] = os.environ) -> str:
    """Which app ran the agent, as far as the hook's environment tells."""
    if agent == "claude" and env.get("CLAUDE_CODE_ENTRYPOINT"):
        return env["CLAUDE_CODE_ENTRYPOINT"][:40]
    if env.get("TERM_PROGRAM") == "vscode" or env.get("VSCODE_PID"):
        return "vscode"
    return "unknown"


def summarize(agent: str, data: dict) -> dict:
    tool_input = (
        data.get("tool_input") if isinstance(data.get("tool_input"), dict) else {}
    )
    detail = (
        tool_input.get("description")
        or tool_input.get("command")
        or tool_input.get("file_path")
        or tool_input.get("url")
        or ""
    )
    return {
        "agent": agent,
        "session_id": str(data.get("session_id") or ""),
        "event": str(data.get("hook_event_name") or ""),
        "notification_type": data.get("notification_type"),
        "tool": data.get("tool_name"),
        "detail": str(detail)[:200] if detail else None,
        "message": str(data.get("message") or data.get("last_assistant_message") or "")[
            :300
        ]
        or None,
        "transcript_path": data.get("transcript_path"),
        "cwd": data.get("cwd"),
        "ts": time.time(),
    }


def record(agent: str, data: dict, directory: Path) -> Path | None:
    event = summarize(agent, data)
    session = re.sub(r"[^A-Za-z0-9_-]", "_", event["session_id"])[:100]
    if not session:
        return None
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"{agent}-{session}.json"
    # Remember when the current turn began, across the events that follow it, so a
    # Stop can tell a long task from a quick reply.
    if event["event"] == "UserPromptSubmit":
        event["turn_started_at"] = event["ts"]
    else:
        try:
            previous = json.loads(target.read_text(encoding="utf-8"))
            event["turn_started_at"] = previous.get("turn_started_at")
        except (OSError, ValueError):
            event["turn_started_at"] = None
    _write_atomic(directory, target, event)
    cutoff = time.time() - KEEP_DAYS * 86400
    for old in directory.glob("*.json"):
        if old.stat().st_mtime < cutoff:
            old.unlink(missing_ok=True)
    return target


def _write_atomic(directory: Path, target: Path, payload: dict) -> None:
    with tempfile.NamedTemporaryFile(
        "w", dir=directory, delete=False, suffix=".tmp", encoding="utf-8"
    ) as tmp:
        json.dump(payload, tmp, ensure_ascii=False)
    os.replace(tmp.name, target)


def outbox_entry(agent: str, data: dict, event: dict) -> dict | None:
    """The durable event for a finished turn or a request for the user, or None."""
    name = event["event"]
    if name == "Stop":
        kind, status = "agent_finished", "turn_completed"
    elif name == "PermissionRequest":
        kind = "agent_waiting"
        status = "question" if event.get("tool") in QUESTION_TOOLS else "approval"
    else:
        return None
    turn_id = str(data.get("turn_id") or "")[:120] or None
    if turn_id:
        # A retried hook for the same turn maps to the same event.
        seed = f"{agent}|{event['session_id']}|{turn_id}|{kind}|{event.get('tool')}"
        event_id = hashlib.sha256(seed.encode()).hexdigest()[:32]
    else:
        event_id = uuid.uuid4().hex
    return {
        "event_id": event_id,
        "kind": kind,
        "status": status,
        "agent": agent,
        "host": host_hint(agent),
        "session_id": event["session_id"],
        "turn_id": turn_id,
        "cwd": event.get("cwd"),
        "transcript_path": event.get("transcript_path"),
        "tool": event.get("tool"),
        "detail": event.get("detail"),
        # The complete final answer; the helper trims and redacts it before sending.
        "message": str(data.get("last_assistant_message") or data.get("message") or "")
        or None,
        "continued": bool(data.get("stop_hook_active")),
        "started_at": event.get("turn_started_at"),
        "finished_at": event["ts"],
        "recorded_at": time.time(),
    }


def queue_event(agent: str, data: dict, event: dict, directory: Path) -> Path | None:
    entry = outbox_entry(agent, data, event)
    if entry is None:
        return None
    directory.mkdir(parents=True, exist_ok=True)
    # Millisecond prefix: the helper sends the oldest first.
    target = (
        directory / f"{int(entry['recorded_at'] * 1000):013d}-{entry['event_id']}.json"
    )
    _write_atomic(directory, target, entry)
    return target


def main() -> None:
    agent = (
        sys.argv[1]
        if len(sys.argv) > 1 and sys.argv[1] in {"claude", "codex"}
        else "claude"
    )
    try:
        data = json.loads(
            sys.stdin.buffer.read().decode("utf-8", errors="replace") or "{}"
        )
        if isinstance(data, dict):
            target = record(agent, data, events_dir())
            if target is not None:
                event = json.loads(target.read_text(encoding="utf-8"))
                queue_event(agent, data, event, outbox_dir())
    except Exception:  # a hook must never disturb the agent
        pass


if __name__ == "__main__":
    main()
