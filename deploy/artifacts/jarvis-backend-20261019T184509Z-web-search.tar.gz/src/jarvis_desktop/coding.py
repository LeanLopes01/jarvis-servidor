"""Read-only report of what the coding agents on this PC are doing.

Claude Code and Codex (both the VS Code extensions and the CLIs) keep every session
as a JSONL file in the user's profile:

    ~/.claude/projects/<project>/<session>.jsonl          (CLAUDE_CONFIG_DIR overrides)
    ~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl          (CODEX_HOME overrides)

Only the end of each recent file is read. The report keeps short excerpts with
secrets removed, because it goes to the server and then to the voice model.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePath
from typing import Any

from .agent_hook import events_dir

TAIL_BYTES = 768 * 1024
HEAD_BYTES = 64 * 1024
LAST_RECORD_BYTES = 8 * 1024
TEXT_LIMIT = 280
ACTION_LIMIT = 6
FILE_LIMIT = 8
ACTIVE_MINUTES = 20  # a "working" session with no new records after this is stalled
APPROVAL_SECONDS = 20  # a tool call this old without a result may await approval
EDIT_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}

_SECRET_LABEL = re.compile(
    r"(?i)\b(senha|password|passwd|pwd|pw|secret|token|api[_-]?key)\b"
    r"((?:[^\n]{0,15}?[:=])|(?:\s+(?:\w+\s+)?(?:é|e|is)\s*:?))\s*['\"]?([^\s'\",;]{3,})"
)
_SECRET_SHAPES = re.compile(
    r"\b(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}"
    r"|xox[abprs]-[A-Za-z0-9-]{10,}|jd1\.[A-Za-z0-9_-]{20,}"
    r"|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}"
    r"|[A-Za-z0-9+/_-]{40,})"
)


def redact(text: str) -> str:
    text = _SECRET_LABEL.sub(lambda m: f"{m.group(1)}{m.group(2)} [removido]", text)
    return _SECRET_SHAPES.sub("[removido]", text)


def clip(text: str | None, limit: int = TEXT_LIMIT) -> str | None:
    if not text:
        return None
    text = redact(re.sub(r"\s+", " ", text).strip())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


@dataclass
class SessionReport:
    agent: str
    project: str
    folder: str | None
    source: str
    title: str | None
    state: str
    detail: str
    minutes_ago: int
    request: str | None = None
    last_message: str | None = None
    recent_actions: list[str] = field(default_factory=list)
    files_changed: list[str] = field(default_factory=list)
    # "exact" when the agent's hooks report approvals and questions for this session,
    # "estimate" when a long-running tool call is the only clue.
    detection: str = "estimate"
    session_id: str | None = None
    project_folder: str | None = None


WAITING_NOTIFICATIONS = {
    "elicitation_dialog",
    "elicitation_url_dialog",
    "agent_needs_input",
}
QUESTION_TOOLS = {"AskUserQuestion"}


SHELL_TOOLS = {"Bash", "PowerShell"}


def _signature(command: str) -> str | None:
    """A literal piece of the command that survives the agents' shell quoting."""
    runs = re.findall(r"[A-Za-z0-9 ._/:=,-]{10,}", command)
    best = max(runs, key=len, default="").strip()
    return best[:50] if len(best) >= 10 else None


def command_running(command: str, since: float) -> bool:
    """Whether a process started for this call is running, i.e. it was approved."""
    signature = _signature(command)
    if signature is None:
        return False
    try:
        import psutil
    except ImportError:
        return False
    for process in psutil.process_iter(["cmdline", "create_time"]):
        try:
            started = process.info["create_time"] or 0
            line = " ".join(process.info["cmdline"] or [])
        except (psutil.Error, TypeError):
            continue
        if started >= since - 10 and signature in line:
            return True
    return False


def _codex_command(payload: dict[str, Any]) -> str | None:
    raw = payload.get("input") or payload.get("arguments") or ""
    raw = raw if isinstance(raw, str) else json.dumps(raw)
    match = re.search(r"cmd\s*[:=]\s*\"((?:[^\"\\]|\\.){1,400})", raw)
    return match.group(1) if match else None


def _attention(
    pending: dict[str, tuple[str, float, str | None]],
    event: dict[str, Any] | None,
    last_time: float,
) -> tuple[str, str] | None:
    """Exact waiting states from the agent's own hook event, when there is one."""
    if pending and list(pending.values())[-1][0] in QUESTION_TOOLS:
        return "question", "is asking you a question and waiting for your answer"
    if event is None:
        return None
    asked = (
        event.get("event") == "PermissionRequest"
        or event.get("notification_type") == "permission_prompt"
    )
    if asked and pending:
        tool, since, command = list(pending.values())[-1]
        # The permission was requested for the call that is still open, and the command
        # has not started: once approved, its process shows up and it is just running.
        if event.get("ts", 0) >= since - 2 and not (
            command and command_running(command, since)
        ):
            what = clip(event.get("detail"), 80)
            name = event.get("tool") or tool
            return "approval", f"waiting for your approval to run {name}" + (
                f": {what}" if what else ""
            )
    if (
        event.get("notification_type") in WAITING_NOTIFICATIONS
        and event.get("ts", 0) >= last_time - 2
    ):
        return "question", "is asking you a question and waiting for your answer"
    return None


def _open_call_state(
    pending: dict[str, tuple[str, float, str | None]], now: float, hooked: bool
) -> tuple[str, str]:
    tool, since, _ = list(pending.values())[-1]
    seconds = int(now - since)
    if hooked:
        # The hooks would have reported a permission prompt: this is just slow.
        return "working", f"running {tool}" + (
            f" for {seconds} s" if seconds > 20 else ""
        )
    if seconds > APPROVAL_SECONDS:
        return "waiting", (
            f"{tool} has been running for {seconds} s; it may be waiting for your "
            "approval (estimate: hooks are not installed for this session)"
        )
    return "working", f"running {tool}"


def _read_records(path: Path, *, head: bool = False) -> list[dict[str, Any]]:
    size = path.stat().st_size
    with path.open("rb") as handle:
        if head:
            data = handle.read(HEAD_BYTES)
        else:
            handle.seek(max(0, size - TAIL_BYTES))
            data = handle.read()
    lines = data.decode("utf-8", errors="replace").splitlines()
    if head:
        lines = lines[:-1] if len(data) == HEAD_BYTES else lines
    elif size > TAIL_BYTES:
        lines = lines[1:]  # the first line was cut by the seek
    records = []
    for line in lines:
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if isinstance(record, dict):
            records.append(record)
    return records


def _timestamp(record: dict[str, Any]) -> float | None:
    value = record.get("timestamp")
    if not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _name(path: str | None) -> str | None:
    return PurePath(path.replace("\\", "/")).name if path else None


def _texts(content: Any) -> list[str]:
    if isinstance(content, str):
        return [content]
    if not isinstance(content, list):
        return []
    return [
        item.get("text", "")
        for item in content
        if isinstance(item, dict)
        and item.get("type") in {"text", "input_text", "output_text"}
    ]


def _human_text(content: Any) -> str | None:
    """The user's own words, without IDE context and reminders the tools inject."""
    parts = [
        text
        for text in _texts(content)
        if text.strip() and not text.lstrip().startswith("<")
    ]
    return "\n".join(parts) or None


def _describe_claude_tool(name: str, data: dict[str, Any]) -> str:
    if name in EDIT_TOOLS or name == "Read":
        return f"{name} {_name(data.get('file_path') or data.get('notebook_path')) or ''}".strip()
    if name in {"Bash", "PowerShell"}:
        return f"{name}: {clip(data.get('description') or data.get('command'), 70)}"
    if name in {"Grep", "Glob"}:
        return f"{name} {clip(data.get('pattern'), 40)}"
    if name in {"Agent", "Task"}:
        return f"subagent: {clip(data.get('description'), 60)}"
    if name in {"WebSearch", "WebFetch"}:
        return f"{name} {clip(data.get('query') or data.get('url'), 60)}"
    return name


def _launch_folder(path: Path, folders: set[str]) -> str | None:
    """The folder the session was opened in, which names the project.

    Claude Code stores a session under its launch path with every other character
    replaced by "-" (c:/J.A.R.V.I.S -> c--J-A-R-V-I-S); the shell may move later.
    """
    slug = path.parent.name.casefold()
    for folder in folders:
        if re.sub(r"[^A-Za-z0-9]", "-", folder).casefold() == slug:
            return folder
    return min(folders, key=len) if folders else None


def parse_claude(
    path: Path, now: float, event: dict[str, Any] | None = None
) -> SessionReport | None:
    records = _read_records(path)
    title = request = folder = source = None
    folders: set[str] = set()
    last_text = None
    actions: list[str] = []
    files: list[str] = []
    pending: dict[str, tuple[str, float, str | None]] = {}
    last: dict[str, Any] | None = None
    last_time = path.stat().st_mtime

    for record in records:
        kind = record.get("type")
        if kind == "ai-title":
            title = record.get("aiTitle") or title
        elif kind == "last-prompt":
            request = record.get("lastPrompt") or request
        if record.get("cwd"):
            folder = record["cwd"]
            folders.add(folder)
        if record.get("entrypoint"):
            source = record["entrypoint"]
        if kind not in {"user", "assistant"} or record.get("isSidechain"):
            continue
        message = record.get("message") or {}
        content = message.get("content")
        when = _timestamp(record) or last_time
        if kind == "assistant" and isinstance(content, list):
            for item in content:
                if not isinstance(item, dict):
                    continue
                if item.get("type") == "text" and item.get("text", "").strip():
                    last_text = item["text"]
                elif item.get("type") == "tool_use":
                    data = (
                        item.get("input") if isinstance(item.get("input"), dict) else {}
                    )
                    actions.append(
                        _describe_claude_tool(item.get("name", "tool"), data)
                    )
                    command = (
                        data.get("command") if item.get("name") in SHELL_TOOLS else None
                    )
                    pending[item.get("id", "")] = (
                        item.get("name", "tool"),
                        when,
                        command,
                    )
                    if item.get("name") in EDIT_TOOLS:
                        changed = _name(
                            data.get("file_path") or data.get("notebook_path")
                        )
                        if changed:
                            files.append(changed)
        elif kind == "user":
            if isinstance(content, list):
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "tool_result":
                        pending.pop(item.get("tool_use_id", ""), None)
            human = _human_text(content)
            if human and not any(
                isinstance(i, dict) and i.get("type") == "tool_result"
                for i in content or []
            ):
                request = request if human.startswith("[Request interrupted") else human
        last = record
        last_time = when

    if last is None:
        return None
    age = now - last_time
    message = last.get("message") or {}
    content = message.get("content")
    attention = _attention(pending, event, last_time)
    if attention:
        state, detail = attention
    elif last.get("type") == "assistant":
        if pending:
            state, detail = _open_call_state(pending, now, event is not None)
        elif message.get("stop_reason") == "end_turn":
            state, detail = (
                "finished",
                "finished its turn and is waiting for your next message",
            )
        else:
            state, detail = "working", "thinking"
    elif any("[Request interrupted" in text for text in _texts(content)):
        state, detail = "interrupted", "you interrupted the last request"
    else:
        state, detail = "working", "working on the request"
    if state == "working" and age > ACTIVE_MINUTES * 60:
        state, detail = (
            "stalled",
            "no activity recently; it may have been closed or stopped",
        )

    return SessionReport(
        agent="claude",
        project=_name(_launch_folder(path, folders) or folder) or path.parent.name,
        session_id=path.stem,
        project_folder=_launch_folder(path, folders) or folder,
        folder=folder,
        source="VS Code" if source == "claude-vscode" else (source or "CLI"),
        title=clip(title, 100),
        state=state,
        detail=detail,
        minutes_ago=int(age // 60),
        request=clip(request),
        last_message=clip(last_text),
        recent_actions=[clip(a, 90) or "" for a in actions[-ACTION_LIMIT:]],
        files_changed=list(dict.fromkeys(reversed(files)))[:FILE_LIMIT],
        detection="exact" if event is not None else "estimate",
    )


def _codex_request(text: str) -> str | None:
    marker = "## My request for Codex:"
    if marker in text:
        return text.split(marker, 1)[1].strip() or None
    if text.lstrip().startswith(("<", "# Context from my IDE setup", "# AGENTS.md")):
        return None
    return text.strip() or None


def _describe_codex_call(payload: dict[str, Any]) -> tuple[str, list[str]]:
    raw = payload.get("input") or payload.get("arguments") or ""
    raw = raw if isinstance(raw, str) else json.dumps(raw)
    files = [
        _name(m.strip()) or ""
        for m in re.findall(r"\*\*\* (?:Update|Add|Delete) File: ([^\n\\\"]+)", raw)
    ]
    if "apply_patch" in raw or files:
        return f"edited {', '.join(files[:3]) or 'files'}", files
    command = re.search(r"cmd\s*[:=]\s*\"((?:[^\"\\]|\\.){1,200})", raw)
    if command:
        return f"command: {clip(command.group(1), 70)}", []
    name = payload.get("name") or "tool"
    namespace = payload.get("namespace")
    return (f"{namespace}.{name}" if namespace else name), []


def parse_codex(
    path: Path, now: float, event: dict[str, Any] | None = None
) -> SessionReport | None:
    folder = source = request = last_text = None
    for record in _read_records(path, head=True)[:5]:
        payload = (
            record.get("payload") if isinstance(record.get("payload"), dict) else {}
        )
        if record.get("type") == "session_meta":
            folder = payload.get("cwd")
            source = payload.get("originator") or payload.get("source")
    started_in = folder
    records = _read_records(path)
    actions: list[str] = []
    files: list[str] = []
    pending: dict[str, tuple[str, float, str | None]] = {}
    state, detail = "finished", "idle"
    last_time = path.stat().st_mtime

    for record in records:
        payload = (
            record.get("payload") if isinstance(record.get("payload"), dict) else {}
        )
        kind = payload.get("type")
        when = _timestamp(record) or last_time
        last_time = when
        if record.get("type") == "turn_context" and payload.get("cwd"):
            folder = payload["cwd"]
        if kind == "message" and payload.get("role") == "user":
            request = (
                _codex_request("\n".join(_texts(payload.get("content")))) or request
            )
        elif kind == "message" and payload.get("role") == "assistant":
            last_text = "\n".join(_texts(payload.get("content"))) or last_text
        elif kind == "agent_message" and payload.get("message"):
            last_text = payload["message"]
        elif kind in {"custom_tool_call", "function_call", "local_shell_call"}:
            description, changed = _describe_codex_call(payload)
            actions.append(description)
            files.extend(changed)
            pending[payload.get("call_id", "")] = (
                description,
                when,
                _codex_command(payload),
            )
        elif kind in {
            "custom_tool_call_output",
            "function_call_output",
            "local_shell_call_output",
        }:
            pending.pop(payload.get("call_id", ""), None)
        elif kind == "patch_apply_end" and isinstance(payload.get("changes"), dict):
            files.extend(_name(p) or "" for p in payload["changes"])
        elif kind == "task_started":
            state, detail = "working", "working on the request"
        elif kind == "task_complete":
            state, detail = (
                "finished",
                "finished the task and is waiting for your next message",
            )
            last_text = payload.get("last_agent_message") or last_text
            pending.clear()
        elif kind == "turn_aborted":
            state, detail = "interrupted", "the last request was interrupted"
            pending.clear()

    if not records:
        return None
    age = now - last_time
    if state == "working" and pending:
        attention = _attention(pending, event, last_time)
        state, detail = attention or _open_call_state(pending, now, event is not None)
    if state == "working" and age > ACTIVE_MINUTES * 60:
        state, detail = (
            "stalled",
            "no activity recently; it may have been closed or stopped",
        )

    return SessionReport(
        agent="codex",
        project=_name(started_in or folder) or "unknown project",
        session_id="-".join(path.stem.split("-")[-5:]),
        project_folder=started_in or folder,
        folder=folder,
        source="VS Code" if source in {"codex_vscode", "vscode"} else (source or "CLI"),
        title=None,
        state=state,
        detail=detail,
        minutes_ago=int(age // 60),
        request=clip(request),
        last_message=clip(last_text),
        recent_actions=[clip(a, 90) or "" for a in actions[-ACTION_LIMIT:]],
        files_changed=[f for f in dict.fromkeys(reversed(files)) if f][:FILE_LIMIT],
        detection="exact" if event is not None else "estimate",
    )


def claude_dir() -> Path:
    return Path(os.environ.get("CLAUDE_CONFIG_DIR") or Path.home() / ".claude")


def codex_dir() -> Path:
    return Path(os.environ.get("CODEX_HOME") or Path.home() / ".codex")


def last_activity(path: Path) -> float:
    """Time of the last record in a session file.

    Codex keeps the active session's file open, and Windows does not refresh the
    modification time of an open file, so the timestamp inside the log is what counts.
    """
    mtime = path.stat().st_mtime
    with path.open("rb") as handle:
        handle.seek(max(0, path.stat().st_size - LAST_RECORD_BYTES))
        lines = handle.read().decode("utf-8", errors="replace").splitlines()
    for line in reversed(lines):
        try:
            record = json.loads(line)
        except ValueError:
            continue
        stamp = _timestamp(record) if isinstance(record, dict) else None
        if stamp is not None:
            return max(stamp, mtime)
    return mtime


def _recent(paths: list[Path], since: float) -> list[Path]:
    dated = []
    for path in paths:
        try:
            # Files untouched for a month are not scanned at all.
            if path.stat().st_mtime < since - 30 * 86400:
                continue
            when = last_activity(path)
        except OSError:
            continue
        if when >= since:
            dated.append((when, path))
    return [path for _, path in sorted(dated, reverse=True)]


def vscode_windows() -> list[str]:
    """Titles of open VS Code windows, e.g. 'agent.py - jarvis - Visual Studio Code'."""
    if sys.platform != "win32":
        return []
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    titles: list[str] = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def collect(hwnd: int, _: int) -> bool:
        if user32.IsWindowVisible(hwnd):
            length = user32.GetWindowTextLengthW(hwnd)
            if length:
                buffer = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buffer, length + 1)
                if buffer.value.endswith("Visual Studio Code"):
                    titles.append(clip(buffer.value, 120) or "")
        return True

    user32.EnumWindows(callback_type(collect), 0)
    return titles


def load_events(directory: Path) -> list[dict[str, Any]]:
    """Latest hook event of each session, written by agent_hook.py."""
    events = []
    for path in directory.glob("*.json"):
        try:
            event = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(event, dict) and event.get("session_id"):
            events.append(event)
    return events


def _event_for(
    agent: str, path: Path, events: list[dict[str, Any]]
) -> dict[str, Any] | None:
    target = str(path).replace("\\", "/").casefold()
    for event in events:
        if event.get("agent") != agent:
            continue
        transcript = (
            str(event.get("transcript_path") or "").replace("\\", "/").casefold()
        )
        if transcript == target or str(event["session_id"]) in path.stem:
            return event
    return None


def activity_report(
    *,
    agent: str = "all",
    hours: float = 12,
    limit: int = 5,
    now: float | None = None,
    claude_root: Path | None = None,
    codex_root: Path | None = None,
    events_root: Path | None = None,
) -> dict[str, Any]:
    now = time.time() if now is None else now
    events = load_events(events_root or events_dir())
    since = now - min(max(hours, 0.25), 72) * 3600
    candidates: list[tuple[str, Path]] = []
    if agent in {"all", "claude"}:
        root = (claude_root or claude_dir()) / "projects"
        candidates += [("claude", p) for p in root.glob("*/*.jsonl")]
    if agent in {"all", "codex"}:
        root = (codex_root or codex_dir()) / "sessions"
        candidates += [("codex", p) for p in root.glob("*/*/*/*.jsonl")]

    kinds = {path: kind for kind, path in candidates}
    sessions = []
    for path in _recent([path for _, path in candidates], since)[
        : min(max(limit, 1), 10)
    ]:
        parser = parse_claude if kinds[path] == "claude" else parse_codex
        try:
            report = parser(path, now, _event_for(kinds[path], path, events))
        except (OSError, ValueError):
            continue
        if report is not None:
            sessions.append(asdict(report))

    return {
        "generated_at": datetime.fromtimestamp(now, timezone.utc).isoformat(
            timespec="seconds"
        ),
        "hours": hours,
        "sessions": sessions,
        "vscode_windows": vscode_windows(),
    }
