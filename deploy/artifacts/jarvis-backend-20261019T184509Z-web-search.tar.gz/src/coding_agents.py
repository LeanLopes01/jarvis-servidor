"""Lets Jarvis report what the coding agents (Claude Code, Codex) on the user's PC are
doing. Read-only: it never sends instructions to them."""

from __future__ import annotations

import asyncio
import sys
from typing import Any, Literal, Protocol

from livekit.agents import RunContext, function_tool
from livekit.agents.llm import ToolError

if __package__:
    from .desktop_link import DesktopLink, DesktopLinkError
    from .jarvis_desktop.coding import activity_report
    from .jarvis_desktop.remote_control import RemoteControlError, start
    from .jarvis_desktop.usage import usage_report
else:
    from desktop_link import DesktopLink, DesktopLinkError
    from jarvis_desktop.coding import activity_report
    from jarvis_desktop.remote_control import RemoteControlError, start
    from jarvis_desktop.usage import usage_report


class CodingReportError(Exception):
    pass


class CodingBackend(Protocol):
    async def report(self, agent: str, hours: float) -> dict[str, Any]: ...

    async def usage(self) -> dict[str, Any]: ...

    async def remote_control(self, chat: str) -> dict[str, Any]: ...


class LocalCoding:
    """The agent runs on the same Windows PC as the coding agents (development)."""

    async def report(self, agent: str, hours: float) -> dict[str, Any]:
        return await asyncio.to_thread(activity_report, agent=agent, hours=hours)

    async def usage(self) -> dict[str, Any]:
        return await asyncio.to_thread(usage_report)

    async def remote_control(self, chat: str) -> dict[str, Any]:
        try:
            return await asyncio.to_thread(start, chat)
        except RemoteControlError as exc:
            raise CodingReportError(str(exc)) from exc


class RemoteCoding:
    """The agent runs on the server; the paired PC builds the report."""

    def __init__(self, link: DesktopLink) -> None:
        self._link = link

    async def report(self, agent: str, hours: float) -> dict[str, Any]:
        try:
            return await self._link.call(
                "coding.activity", {"agent": agent, "hours": hours, "limit": 5}
            )
        except DesktopLinkError as exc:
            raise CodingReportError(str(exc)) from exc

    async def usage(self) -> dict[str, Any]:
        try:
            return await self._link.call("coding.usage", {})
        except DesktopLinkError as exc:
            raise CodingReportError(str(exc)) from exc

    async def remote_control(self, chat: str) -> dict[str, Any]:
        try:
            return await self._link.call("claude.remote_control", {"chat": chat})
        except DesktopLinkError as exc:
            raise CodingReportError(str(exc)) from exc


def local_coding_available() -> bool:
    return sys.platform == "win32"


class CodingAgentTools:
    def __init__(self, backend: CodingBackend | None) -> None:
        self.backend = backend

    @property
    def tools(self) -> list:
        if self.backend is None:
            return []
        return [
            self.check_coding_agents,
            self.check_ai_usage,
            self.start_claude_remote_control,
        ]

    @function_tool()
    async def check_coding_agents(
        self,
        context: RunContext,
        agent: Literal["all", "claude", "codex"] = "all",
        hours: int = 12,
    ) -> dict[str, Any]:
        """Report what the coding agents on the user's computer are doing or did recently.

        Covers Claude Code and Codex, including their VS Code extensions. Use it when
        the user asks about Claude, Codex, the coding agents, VS Code, or the progress
        of programming work. Each session lists the project, what was asked, its state
        (working, waiting, finished, interrupted, stalled), recent actions, changed
        files, and the agent's latest message, which are excerpts from local logs.

        Args:
            agent: "all", "claude" or "codex". Use "all" unless the user names one.
            hours: How far back to look, from 1 to 72. Keep the default of 12, even
                for "right now", unless the user names a period: a session that
                finished recently is still part of the current picture.
        """
        assert self.backend is not None
        try:
            report = await self.backend.report(agent, float(max(1, min(hours, 72))))
        except CodingReportError as exc:
            raise ToolError(str(exc)) from exc
        if not report.get("sessions"):
            report["note"] = "No coding agent sessions in that period."
        return report

    @function_tool()
    async def check_ai_usage(self, context: RunContext) -> dict[str, Any]:
        """Report how much of the Claude Code and Codex subscription limits is used.

        Use it when the user asks about their usage, session limit, how much is left,
        or when the limits reset. Each agent has a 5-hour window and a weekly window,
        with the percentage used and the local time it resets; limit_reached means
        the agent is blocked until that time.
        """
        assert self.backend is not None
        try:
            return await self.backend.usage()
        except CodingReportError as exc:
            raise ToolError(str(exc)) from exc

    @function_tool()
    async def start_claude_remote_control(
        self, context: RunContext, chat: str
    ) -> dict[str, Any]:
        """Open one Claude Code chat with Remote Control so the user can continue it
        from the Claude mobile app or claude.ai/code.

        Use it only when the user asks for it and names the chat. If you are not sure
        which chat they mean, call check_coding_agents and ask them to choose.

        Args:
            chat: Words from the chat's title or project, as the user said them.
        """
        assert self.backend is not None
        try:
            return await self.backend.remote_control(chat)
        except CodingReportError as exc:
            raise ToolError(str(exc)) from exc
