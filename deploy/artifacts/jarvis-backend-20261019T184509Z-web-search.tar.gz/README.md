<a href="https://livekit.io/">
  <img src="./.github/assets/livekit-mark.png" alt="LiveKit logo" width="100" height="100">
</a>

# LiveKit Agents starter for Python

A starter project for building voice AI apps with [LiveKit Agents for Python](https://github.com/livekit/agents) and [LiveKit Cloud](https://cloud.livekit.io/).

The starter includes:

- A simple [voice AI assistant](https://docs.livekit.io/agents/start/voice-ai/) to extend and customize.
- A voice pipeline built on [LiveKit Inference](https://docs.livekit.io/agents/models/inference/), which gives you access to [models](https://docs.livekit.io/agents/models/) from top labs with no extra configuration:
  - The default LLM is Gemma 4 31B, an open-weight model [hosted by LiveKit](https://docs.livekit.io/agents/models/llm/livekit/) and tuned for voice AI.
  - The default TTS is [Fish Audio S2.1 Pro](https://docs.livekit.io/agents/models/tts/fishaudio/), an expressive and cost-effective voice.
  - More than 50 other models are available from OpenAI, Cartesia, Deepgram, and other providers.
  - [Realtime models](https://docs.livekit.io/agents/models/realtime/) and many others are available through the [plugin ecosystem](https://docs.livekit.io/agents/models/#plugins).
- [Expressive mode](https://docs.livekit.io/agents/models/tts/expressive/), on by default, so your agent's voice carries emotion and pacing that fit the conversation.
- [Keyterms](https://docs.livekit.io/agents/models/stt/keyterms/), on by default, so speech recognition gets your names, brands, and jargon right, including names it picks up during the conversation, like a caller's.
- [LiveKit Turn Detector](https://docs.livekit.io/agents/logic/turns/turn-detector/), which knows when the user has finished speaking, in 14 languages.
- [Adaptive interruption handling](https://docs.livekit.io/agents/logic/turns/adaptive-interruption-handling/), which tells a real interruption from an "uh-huh" or background noise, so your agent doesn't stop talking when it shouldn't.
- [Background voice cancellation](https://docs.livekit.io/transport/media/noise-cancellation/).
- Session transcripts, traces, and recordings from LiveKit [Agent Observability](https://docs.livekit.io/testing/observability/).
- [Simulations](https://docs.livekit.io/testing/simulations/) that test full conversations with your agent, run in CI on every merge to `main`.
- A `Dockerfile` for [deploying to LiveKit Cloud](https://docs.livekit.io/deploy/agents/).

The starter works with any [custom web or mobile frontend](https://docs.livekit.io/frontends/) or with [telephony](https://docs.livekit.io/telephony/).

## Using coding agents

This project works with coding agents like [Claude Code](https://claude.com/product/claude-code), [Cursor](https://www.cursor.com/), and [Codex](https://openai.com/codex/).

LiveKit offers both a CLI and an [MCP server](https://docs.livekit.io/reference/developer-tools/docs-mcp/) for browsing and searching its documentation. Search returns short excerpts, so fetch the full page to read the details:

```console
lk docs search "testing my agent"
lk docs get-page /testing/unit-tests
```

The project also includes an [`AGENTS.md`](AGENTS.md) file, so your coding agent follows LiveKit's best practices for workflows, handoffs, and testing, and tries its changes with the [agent debugger](https://docs.livekit.io/testing/debugger/).

For more guidance at each stage of the work, from building and debugging to testing and deploying, install LiveKit's [agent skills](https://docs.livekit.io/intro/coding-agents/#agent-skills). The CLI installs them for the coding agents on your machine and adds the Docs MCP server to their config. `lk agent init` offers to do this when it creates your project, or you can run it yourself:

```console
lk skills install
```

Run `lk skills update` to get the latest skills, and commit `skills-lock.json` along with them. See the [coding agents guide](https://docs.livekit.io/intro/coding-agents/) for more details.

## Dev setup

Install the [LiveKit CLI](https://docs.livekit.io/intro/basics/cli/), version 2.18.8 or later:

- **macOS:** `brew install livekit-cli`
- **Linux:** `curl -sSL https://get.livekit.io/cli | bash`
- **Windows:** `winget install LiveKit.LiveKitCLI`

Check your version with `lk --version`. To update an existing install, see [Update the CLI](https://docs.livekit.io/reference/developer-tools/livekit-cli/#updates).

Then create a project from this template. The CLI clones the template and configures your environment:

```console
lk cloud auth
lk agent init my-agent --template agent-starter-python
```

<details>
<summary>Set up the project manually</summary>

Clone the repository and install dependencies into a virtual environment with [uv](https://docs.astral.sh/uv/):

```console
git clone https://github.com/livekit-examples/agent-starter-python.git
cd agent-starter-python
uv sync
```

Sign up for [LiveKit Cloud](https://cloud.livekit.io/), then copy `.env.example` to `.env.local` and fill it in. To have the CLI write your project's URL and API keys into the file instead, run:

```console
lk cloud auth
lk app env --write --destination .env.local
```

</details>

## Run the agent

### Jarvis tutorial setup

This project's `src/agent.py` uses Gemini Live for speech and Playwright for browser
tools. From the `jarvis` directory, install both the Python dependencies and Chromium:

```console
uv sync --locked
uv run playwright install chromium
```

Set `GOOGLE_API_KEY` in `.env.local` alongside `LIVEKIT_URL`, `LIVEKIT_API_KEY`, and
`LIVEKIT_API_SECRET` (see `.env.example`). The [Gemini Live plugin documentation](https://docs.livekit.io/agents/models/realtime/plugins/gemini/)
describes authentication and turn detection. The agent uses Gemini's built-in audio turn
detection (`realtime_llm`), with preemptive generation disabled. Do not disable
Gemini's automatic activity detection: this plugin does not implement client-side
`commit_audio`, which can leave replies delayed across turns. Gemini 3.1 does not
support asynchronous function-response scheduling.

Keep `src/browser.py` and `src/tools.py` alongside `src/agent.py`; copying only the
agent entrypoint from the tutorial is insufficient. On Windows and macOS the browser
opens visibly on the local desktop when a browser tool is used. On a Linux host without
a display, such as a home server running the agent as a service, it runs headless; set
`JARVIS_BROWSER_HEADLESS=1` or `0` to force either mode. A headless host still needs
Chromium's system libraries (`uv run playwright install-deps chromium`, run with
administrator rights) in addition to `uv run playwright install chromium`.

On a CPU without AVX2 (the home server is a Xeon E5-2670 v2), set
`LIVEKIT_AGENTS_PRELOAD_LOCAL_INFERENCE=0`. `livekit-local-inference` 0.2.7 is built
with AVX2, and preloading its local VAD and turn models kills the job processes with an
illegal instruction. Jarvis does not need those models, because Gemini handles turn
detection. `JARVIS_IDLE_PROCESSES` (default 1) sets how many prewarmed job processes
`uv run src/agent.py start` keeps ready; the SDK default is one per CPU core.

The Spotify tools control the Spotify desktop app through `spotify_cli` on the machine
running the agent. When that CLI is not installed, as on a Linux server, the tools are
left out and Jarvis tells the user that Spotify is unavailable.

Validate the local modules and browser integration with `uv run python -m pytest`.
Start the agent with `lk agent dev` or `uv run src/agent.py dev`.

For this Gemini voice agent, use audio mode in the debugger:

```console
lk agent debugger start --audio
lk agent debugger say "Jarvis, you there?"
lk agent debugger stop
```

Audio debugging uses LiveKit Inference TTS. The text-mode smoke test returned
`1007 Precondition check failed` with this model; the audio-mode test completed.

The `lk agent console`, `lk agent dev`, and `lk agent debugger` commands run your agent on your own machine. To talk to it in your terminal:

```console
lk agent console
```

To connect it to LiveKit Cloud so a frontend, a phone call, or the [Agent Console](https://docs.livekit.io/testing/agent-console/) can reach it:

```console
lk agent dev
```

To let a coding agent or a script test it one text turn at a time, use the [agent debugger](https://docs.livekit.io/testing/debugger/). Each turn prints the agent's reply along with the tool calls and handoffs behind it:

```console
lk agent debugger start
lk agent debugger say "Hi, what can you do?"
lk agent debugger stop
```

In production, run the agent directly:

```console
uv run src/agent.py start
```

## Frontends and telephony

Pair the agent with a prebuilt frontend starter, or add telephony:

| Platform | Link | Description |
|----------|----------|-------------|
| **Web** | [`livekit-examples/agent-starter-react`](https://github.com/livekit-examples/agent-starter-react) | Web voice AI assistant with React & Next.js |
| **iOS/macOS** | [`livekit-examples/agent-starter-swift`](https://github.com/livekit-examples/agent-starter-swift) | Native iOS, macOS, and visionOS voice AI assistant |
| **Flutter** | [`livekit-examples/agent-starter-flutter`](https://github.com/livekit-examples/agent-starter-flutter) | Cross-platform voice AI assistant app |
| **React Native** | [`livekit-examples/voice-assistant-react-native`](https://github.com/livekit-examples/voice-assistant-react-native) | Native mobile app with React Native & Expo |
| **Android** | [`livekit-examples/agent-starter-android`](https://github.com/livekit-examples/agent-starter-android) | Native Android app with Kotlin & Jetpack Compose |
| **Web Embed** | [`livekit-examples/agent-starter-embed`](https://github.com/livekit-examples/agent-starter-embed) | Voice AI widget for any website |
| **Telephony** | [Documentation](https://docs.livekit.io/telephony/) | Add inbound or outbound calling to your agent |

For more options, see the [frontend guide](https://docs.livekit.io/frontends/).

## Testing and debugging

Simulations run full multi-turn conversations between a simulated user and your agent on LiveKit Cloud, then judge each transcript. The scenarios live in [`scenarios.yaml`](scenarios.yaml). Run them locally with the CLI:

```console
lk agent simulate text --scenarios scenarios.yaml
```

The `Simulations` workflow in [`.github/workflows/simulations.yml`](.github/workflows/simulations.yml) runs the same file on every merge to `main`, and on demand from the Actions tab. It doesn't run on every pull request push because each run uses real inference. See the [simulations guide](https://docs.livekit.io/testing/simulations/) for how to write scenarios and read results.

To check a change turn by turn without a live session, use the [agent debugger](https://docs.livekit.io/testing/debugger/) shown in [Run the agent](#run-the-agent).

To debug a running agent, open it in the [Agent Console](https://docs.livekit.io/testing/agent-console/). It shows events, tool calls, and model timing as you talk to the agent. To stream logs from a deployed agent, run `lk agent logs`.

## Using this template for your own project

After you create your own project from this template:

- **Commit `uv.lock`.** The template doesn't track it, but your project should, for reproducible builds. If you deploy to LiveKit Cloud, commit `livekit.toml` too.
- **Add repository secrets.** Add `LIVEKIT_URL`, `LIVEKIT_API_KEY`, and `LIVEKIT_API_SECRET` as [repository secrets](https://docs.github.com/en/actions/how-tos/writing-workflows/choosing-what-your-workflow-does/using-secrets-in-github-actions) so the simulations can run in CI.

## Deploying to production

To deploy the agent to LiveKit Cloud or another environment with the included `Dockerfile`, see the [deployment guide](https://docs.livekit.io/deploy/agents/).

### Jarvis home server (on-demand agent)

Web research is answered aloud by default. `search_the_web` runs on the server
and never opens the user's PC or phone browser. `open_on_device` is reserved for
explicit requests to open/show a page.

Search first uses a Google AI Overview provider when `SERPAPI_API_KEY` is set;
otherwise it uses Gemini with Google Search grounding (`GOOGLE_API_KEY`, or
`GEMINI_API_KEY`; model configurable with `JARVIS_SEARCH_MODEL`, default
`gemini-3.8-flash`). Grounded answers require returned search queries and source
links. They are explicitly labelled as separate from Google's AI Overview and
first organic result. When Google is unavailable (including quota exhaustion),
Bing web-result snippets provide a labelled fallback. If all providers fail,
JARVIS reports that it has no verified result. No CAPTCHA bypass is attempted.

For the literal Google Search overview, set `SERPAPI_API_KEY` in the server's
agent environment. Its absence is reported as `overview_provider_not_configured`;
some queries have no overview even with the provider configured. Google may show
different results by location/account, so this is not a copy of a personalised
browser session. Search credentials are never included in returned results.

Jarvis runs on the home server (`lean@192.168.15.24`), but only while a call is open:

- `jarvis-control.service` (always on, `src/jarvis_control`) listens on `127.0.0.1:8090`,
  published as `https://jarvis-api.docjediwho.com.br` by the Cloudflare tunnel. The app
  asks it for a session; it starts `jarvis-agent.service`, waits for the worker to
  register (the agent writes `/run/jarvis-agent/ready`), creates a room, dispatches
  `my-agent` explicitly, and returns a 15-minute LiveKit token for that room only.
- It watches each room. A session ends when the app sends `DELETE`, the room closes
  (the agent ended the call, or the phone vanished), the user never joins (90 s), or the
  user stays away longer than the reconnect grace (90 s). The agent unit stops 30 s
  after the last session ends. Heartbeats alone never keep an empty room alive.
- `jarvis-agent.service` runs as the `jarvis` user with systemd sandboxing. A polkit rule
  lets `jarvis-control` start and stop only that unit. Secrets live in `/etc/jarvis/*.env`.
- An internal API on `127.0.0.1:8091` (never tunnelled, separate token) lets the agent
  run actions on the user's Windows PC through `src/jarvis_desktop`, which keeps an
  outbound WebSocket to `/v1/desktop/ws`. Spotify tools use it when `spotify_cli` is not
  installed beside the agent.
- `check_coding_agents` reports what Claude Code and Codex (CLI or VS Code extensions)
  are doing on the PC: `src/jarvis_desktop/coding.py` reads the tail of their session
  logs (`~/.claude/projects`, `~/.codex/sessions`) and returns per-session project,
  request, state, recent actions, changed files and last message, with secrets
  redacted. It is read-only; it never sends instructions to those agents.
  `python -m jarvis_desktop install-hooks` adds async hooks (`agent_hook.py`) to
  `~/.claude/settings.json` and `~/.codex/hooks.json` so `PermissionRequest` and
  question notifications are reported exactly; an open call whose process is running
  counts as approved. Codex runs new hooks only after you trust them with `/hooks`.
- `look_at_vscode` takes one screenshot of a VS Code window on the PC (only windows
  titled "... - Visual Studio Code", via `PrintWindow`) and pushes it into Gemini's
  video input. The PC beeps on each capture; `python -m jarvis_desktop capture off`
  stops offering it.
- `src/documents.py` reads the user's Nextcloud through WebDAV as the read-only
  `jarvis-reader` account (search by name, list, read text/PDF/DOCX/ODT in parts).

Publish from the PC with `deploy/deploy.sh` (Git Bash). It lints, tests, packages an
explicit file list and runs `sudo jarvis-deploy` on the server, which installs the
release under `/opt/jarvis/releases`, runs the tests as `jarvis`, smoke-tests a real
dispatch on the server's CPU, then switches `/opt/jarvis/current`. A failed smoke test
keeps the previous release. `deploy/deploy.sh --rollback` returns to the previous one.

Pair devices with one-time codes printed on the server:

```console
sudo jarvis-control pair --kind app       # enter it in the app's pairing dialog
sudo jarvis-control pair --kind desktop   # python -m jarvis_desktop pair --code ...
sudo jarvis-control devices               # list; `revoke ID` to remove one
```

The Windows helper runs from `jarvis/src` with the project's virtual environment:
`python -m jarvis_desktop pair --code ...`, then `install-startup` to start it hidden at
logon (`uninstall-startup` and `stop` undo it). Its log is in
`%LOCALAPPDATA%\JarvisDesktop\desktop.log`.

## Self-hosted LiveKit

You can self-host LiveKit instead of using LiveKit Cloud. See the [self-hosting guide](https://docs.livekit.io/transport/self-hosting/local/). If you self-host, use [model plugins](https://docs.livekit.io/agents/models/#plugins) instead of LiveKit Inference, and remove the [LiveKit Cloud noise cancellation](https://docs.livekit.io/transport/media/noise-cancellation/) plugin.

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.

### Browser audio troubleshooting

If replies stop after a word, first retest with headphones. Speaker audio can be
picked up by the microphone and interpreted as an interruption. Enable echo
cancellation in the browser client's microphone settings where available. The
server-side noise filter is not a replacement for microphone echo cancellation.
After changing turn detection, stop the old agent with Ctrl+C, restart
`lk agent dev`, and disconnect/reconnect the browser to create a fresh session.
The consecutive-question scenario in `scenarios.yaml` should also be exercised
with the audio debugger; text simulations do not validate microphone turn-taking.
